let products = [];
let activeFilter = "All";
const grid = document.getElementById("productGrid");
const statusText = document.getElementById("liveStatus");
document.getElementById("year").textContent = new Date().getFullYear();

async function loadProducts() {
  try {
    const response = await fetch("/api/products");
    if (!response.ok) throw new Error("API unavailable");
    products = await response.json();
    statusText.textContent = "Connected";
    renderProducts();
  } catch (error) {
    statusText.textContent = "Demo mode";
    grid.innerHTML = '<div class="empty">Could not connect to the product server. Start the Python app using the README instructions and refresh.</div>';
  }
}
function renderProducts() {
  const query = document.getElementById("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p =>
    (activeFilter === "All" || p.category === activeFilter) &&
    p.name.toLowerCase().includes(query)
  );
  if (!filtered.length) {
    grid.innerHTML = '<div class="empty">No produce found. Try another search.</div>';
    return;
  }
  grid.innerHTML = filtered.map((p, i) => {
    const low = p.quantity <= 10;
    const price = Number(p.price).toLocaleString("en-IN", {maximumFractionDigits: 2});
    return `<article class="product-card">
      <div class="product-visual" style="background:${["#f0f3e7","#f4efe4","#f5eae3","#edf1e5"][i%4]}">
        <span class="category-tag">${p.category}</span>
        <span class="stock-tag ${low ? "low" : ""}">${p.quantity > 0 ? (low ? "Low stock" : "In stock") : "Out of stock"}</span>
        <span class="product-emoji" role="img" aria-label="${p.name}">${p.emoji || "🌿"}</span>
      </div>
      <div class="product-info"><h3>${escapeHtml(p.name)}</h3><span class="unit">Price per ${escapeHtml(p.unit)}</span>
        <div class="price-row"><div class="price">₹${price}<small> / ${escapeHtml(p.unit)}</small></div><span class="quantity">${p.quantity} ${p.unit === "piece" ? "pcs" : "kg"} available</span></div>
      </div></article>`;
  }).join("");
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter;
    renderProducts();
  });
});
document.getElementById("searchInput").addEventListener("input", renderProducts);
loadProducts();


// Decorative glass-like bubbles drifting upward in the background.
(function createBubbles() {
  const layer = document.querySelector(".bubble-layer");
  if (!layer || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  for (let i = 0; i < 18; i++) {
    const bubble = document.createElement("span");
    bubble.className = "bubble";
    const size = 12 + Math.random() * 34;
    bubble.style.width = size + "px";
    bubble.style.height = size + "px";
    bubble.style.left = (Math.random() * 100) + "%";
    bubble.style.animationDuration = (12 + Math.random() * 18) + "s";
    bubble.style.animationDelay = (-Math.random() * 28) + "s";
    layer.appendChild(bubble);
  }
})();
